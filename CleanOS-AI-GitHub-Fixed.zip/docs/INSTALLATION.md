# Instalação e desenvolvimento

## Requisitos
Node.js 20.11+, npm 10+, Docker Compose v2. Para compilar Android/iOS: Android Studio SDK ou Xcode em macOS; este ambiente Linux não compila nem assina iOS.

## API
1. `cp .env.example .env` e gerar secrets com `openssl rand -hex 32` para `JWT_ACCESS_SECRET` e `JWT_REFRESH_SECRET`.
2. `npm install`
3. `docker compose up -d postgres redis`.
4. `npm run db:generate`.
5. `npm run db:dev -w @cleanos/api` (dev cria/aplica migration; produção usa `npm run db:migrate`).
6. Provisione a conta Master: `MASTER_EMAIL=seu-email MASTER_PASSWORD='senha-unica-de-16-caracteres-ou-mais' npm run seed:master -w @cleanos/api`. O seed é idempotente e guarda apenas hash bcrypt; nunca coloque a senha no Git.
7. `npm run dev:api`. Health check: `GET http://localhost:4000/api/health`.

## Desktop
`npm run dev -w @cleanos/desktop` abre Vite e o shell Electron. Build: `npm run build -w @cleanos/desktop`. Para blur, forneça modelo ONNX por `AI_MODEL_PATH`, compatível com tensor float32 NCHW 1×3×224×224 e probabilidade de imagem borrada no índice 1. Modelo não incluído. Testes: `npm run test -w @cleanos/desktop`.

## Mobile
O app usa Expo SDK 55 / React Native 0.83. O projeto nativo já está incluído em `frontend-mobile/android` e `frontend-mobile/ios`; para regenerá-lo, execute `npm run prebuild -w @cleanos/mobile`. Android suporta API 24+ (Android 7) e compila/alvo API 36. Build Android: `npm run android -w @cleanos/mobile` (device/emulator conectado) ou Gradle `cd frontend-mobile/android && ./gradlew assembleRelease`. iOS requer macOS e Xcode 16.1+; abra `frontend-mobile/ios/CleanOS.xcodeproj`/workspace após instalar Pods e configure Team de assinatura. iOS mínimo 15.1. No iOS, a tela inicial é login Master por e-mail/senha contra `/api/auth/login`; a sessão fica no Keychain via SecureStore. Configure `EXPO_PUBLIC_API_URL` com a URL HTTPS da API. É necessário definir bundle/package identifiers definitivos, credenciais de assinatura e metadados de privacidade antes da submissão.

## Operações no desktop
- Escolha uma pasta de teste com cópias não valiosas.
- Execute análise; confira caminho, classe e sugestão.
- Organização move somente itens que você marcou.
- Exclusão é permanente e só permite duplicatas exatas marcadas. Não use com a única cópia do arquivo.

## Variáveis
`.env.example` lista as opções. Stripe Checkout requer Stripe secret, webhook secret e price IDs configurados. Não publique `.env`, service account Google nem chave privada Apple. A API deve ficar atrás de HTTPS e controle de taxa antes de exposição pública.
