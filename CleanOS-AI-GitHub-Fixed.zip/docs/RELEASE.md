# Publicação e operação

## Estado
Este starter é uma base de desenvolvimento/teste, não um binário comercial pronto para lojas. Não existem credenciais, certificados, modelo IA ou cadastros de produto fornecidos. Não invente status de assinatura nem habilite benefícios sem verificação server-side.

## Desktop / Microsoft Store
1. Escolha package/app identity e editor definitivos.
2. Atualize `appId`, nome, ícones e metadados do electron-builder.
3. Adicione assinatura Authenticode e pipeline de release Windows.
4. Teste instalador, atualização, desinstalação e caminho de dados; submeta via Partner Center/Store conforme formato vigente.

## Google Play
1. O nativo está configurado com `minSdkVersion 24` (Android 7) e `compileSdk`/`targetSdk` 36; mantenha API 36+ para envios novos ao Play.
2. Defina `applicationId` definitivo e política de privacidade.
3. Gere keystore fora do repositório; configure secrets do CI e assinatura AAB.
4. Adicione SDK Billing compatível com Expo dev-client e fluxo de restauração; configure produtos Pro mensal/anual/lifetime.
5. Implemente validação de compra e notificações de servidor RTDN no backend, incluindo idempotência, cancelamentos, reembolsos e testes Play.
6. Atenda Data safety, permissões de mídia e teste fechado.

## App Store
1. Build e assinatura em macOS/Xcode 16.1+; bundle ID, Team ID e certificados reais. Deployment target mínimo configurado em iOS 15.1 pelo Expo SDK 55.
2. Valide em dispositivos reais; Apple não oferece um limite máximo suportado no Info.plist.
3. Configure StoreKit 2/IAP mensal, anual e lifetime, restore purchases, App Store Server API/notifications V2 e verificação de JWS no backend.
4. O primeiro ecrã iOS é login Master e-mail/senha; crie a conta com `MASTER_EMAIL` e `MASTER_PASSWORD` por `npm run seed:master -w @cleanos/api`. Nunca compile credenciais dentro do app.
5. Justifique permissões, privacidade, exclusão de conta e revisão; teste TestFlight.

## Backend
- Use PostgreSQL gerenciado com backups/PITR, Redis privado e TLS.
- Provisionar `.env` por secret manager, não por GitHub plaintext.
- Terminar HTTPS no ingress; configurar CORS, rate limit, monitoramento, alertas, política de retenção e exclusão/exportação de conta.
- `docker compose` é ambiente de dev; em produção, separar migração e deploy. Executar migrations antes de promover API.
- Configurar e testar Stripe Webhook (checkout completed, renewals, failed payment, cancellation/refund). O código atual cobre apenas checkout completed; outros eventos requerem atualização de estado antes de premium comercial.
- Fazer revisão de segurança, testes com restore/backup e auditoria de cobertura. CI é verificação contínua, não atestado de conformidade.
