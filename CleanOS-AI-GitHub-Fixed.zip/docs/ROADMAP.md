# Roadmap

## Disponível neste starter
- API JWT/Prisma com cadastro, login, refresh token rotativo, dispositivos, sincronização de eventos, histórico, relatórios agregados semanais, Stripe Checkout e webhook assinado.
- Desktop com telemetria best-effort, scan de pasta consentida, hashes de duplicatas exatas, arquivos grandes, ONNX blur configurável, organização por extensão e limpeza selecionada.
- Mobile Expo com leitura de bateria/armazenamento, permissão solicitada para biblioteca, limites iOS reconhecidos, SecureStore disponível via Expo.

## Antes de beta privado
- Extrair módulos/domínios e rate limiting robusto; recuperação de senha, MFA/biometria local, remoção/exportação de conta.
- Implementar API cliente autenticada e persistência segura; validar refresh, logout e sincronização offline/conflitos.
- Adotar modelo de blur com licença/dataset claros e avaliação calibrada; testar em dispositivos reais.
- IAP Apple/Google com verificação de recibo/JWS, Android Play Developer API/RTDN, restauração e estados de reembolso.
- Ampliar testes unitários, integração e E2E para pelo menos 90% de cobertura real nos módulos críticos.

## Comercial
- Similaridade perceptual (pHash/embeddings), vídeos pesados, organização com preview/undo e limpeza assistida para cada plataforma.
- Identificação de apps sem uso onde SO e permissão permitirem.
- Modo piloto com consentimento, agenda gerenciada por sistema, orçamento de operação e relatórios por push/email.
- Criptografia de dados sincronizados, gestão de chaves, retenção configurável e política/auditoria.
- Reprodutibilidade/SBOM, hardening, acessibilidade, localização, beta/store review, telemetria opt-in e operação incident response.
