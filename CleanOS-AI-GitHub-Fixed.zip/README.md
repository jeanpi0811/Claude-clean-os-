# CleanOS AI

Monorepo de diagnóstico e organização local para Windows e mobile, em TypeScript: Electron/React, React Native/Expo, API NestJS, PostgreSQL, Redis e inferência ONNX opcional.

## Recursos implementados
- **API**: JWT access/refresh com hashes de senha e rotação de refresh token; rotas protegidas; dispositivos e eventos de sincronização; histórico; relatórios semanais agendados; Stripe Checkout + webhook assinado; migrations Prisma.
- **Desktop**: métricas de sistema disponíveis, scan consentido da pasta escolhida, arquivos grandes, duplicatas binariamente idênticas, classificação ONNX opcional de blur, organização revisável e limpeza somente após seleção.
- **Mobile**: React Native/Expo, consulta de espaço livre e bateria, permissão explícita da biblioteca, UX dark, e limites de API do iOS respeitados.
- Compose, workflow GitHub Actions, testes unitários iniciais, documentação e assets originais.

## Limites e requisitos pré-lançamento
Não declare este starter pronto para as lojas: builds assinados exigem certificados/contas de publicação e identificadores definitivos; Apple IAP e Google Play Billing ainda precisam de clientes nativos e validação de compras no servidor. Stripe precisa de chaves/price IDs. O classificador ONNX precisa de modelo compatível (entrada RGB NCHW 1×3×224×224; saída com probabilidade de blur na classe 1). Borramento e temperatura/GPU/bateria não são reportados quando o recurso/sensor está indisponível. iOS não permite limpeza de cache de outros apps. Não há detecção de aplicativos pouco usados, detecção por similaridade visual, piloto automático cliente contínuo nem cobertura comprovada de 90%; esses itens estão no roadmap. Não sincronizamos fotos/documentos, apenas eventos e metadados consentidos.

## Início rápido
Requisitos: Node 20+, npm 10+, Docker Engine/Compose.

```bash
cp .env.example .env
# Defina JWT_ACCESS_SECRET e JWT_REFRESH_SECRET com valores aleatórios de 32+ bytes.
npm install
docker compose up -d postgres redis
npm run db:generate
npm run db:dev -w @cleanos/api
MASTER_EMAIL=admin@example.com MASTER_PASSWORD='use-a-unique-secret-of-16-chars-or-more' npm run seed:master -w @cleanos/api
npm run dev:api
# Em outro terminal: npm run dev -w @cleanos/desktop
```

Leia [instalação](docs/INSTALLATION.md), [arquitetura](docs/ARCHITECTURE.md), [segurança e auditoria](docs/SECURITY.md), [publicação](docs/RELEASE.md), [roadmap](docs/ROADMAP.md), [guia do desktop](frontend-desktop/README.md) e [guia mobile](frontend-mobile/README.md).

O app iOS apresenta login e-mail/senha Master na tela inicial; provisione a conta pelo seed sem colocar credenciais no código. Mobile está em Expo SDK 55 / React Native 0.83, Android mínimo 7 (API 24), `compileSdk`/`targetSdk` 36 e iOS mínimo 15.1. Valide a matriz em dispositivos reais; a Apple não oferece limite máximo de versão do iOS no app. O projeto nativo já foi gerado, mas não está assinado nem compilado por esta entrega.

**Segurança operacional**: confira sugestões antes de mover; exclusões permanentes limitam-se às duplicatas exatas que você selecionou. Faça backup antes de testar com dados reais.
