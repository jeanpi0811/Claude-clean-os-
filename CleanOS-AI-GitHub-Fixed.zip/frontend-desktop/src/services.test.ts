import {describe,it,expect} from 'vitest';
import {isWithin} from './path-safety';
describe('isWithin',()=>{it('aceita raiz e filhos',()=>{expect(isWithin('/tmp/media','/tmp/media/a.jpg')).toBe(true);expect(isWithin('/tmp/media','/tmp/media')).toBe(true);});it('rejeita caminhos fora da raiz',()=>{expect(isWithin('/tmp/media','/tmp/media-evil/a')).toBe(false);expect(isWithin('/tmp/media','/etc/passwd')).toBe(false);});});
