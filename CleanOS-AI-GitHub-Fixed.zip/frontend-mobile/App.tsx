import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as Battery from 'expo-battery';
import * as MediaLibrary from 'expo-media-library';
import * as FileSystem from 'expo-file-system';
import { authenticateBiometric } from './src/secure-api';
import { DEFAULT_SETTINGS, loadSettings, setBiometricLock, setProUnlocked, type Settings } from './src/store';

const cyan = '#51D7F3';
const muted = '#8494AA';
type Tab = 'Início' | 'Analisar' | 'Relatórios' | 'Conta';
interface Photo { id: string; uri: string; filename: string; creationTime: number }

function App() {
  const [battery, setBattery] = useState<number | null>(null);
  const [free, setFree] = useState<number | null>(null);
  const [photos, setPhotos] = useState<number | null>(null);
  const [library, setLibrary] = useState<Photo[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [confirmVisible, setConfirmVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<Tab>('Início');
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [locked, setLocked] = useState(false);

  const refresh = useCallback(async () => {
    try { const b = await Battery.getBatteryLevelAsync(); setBattery(b >= 0 ? Math.round(b * 100) : null); } catch { setBattery(null); }
    try { setFree(await FileSystem.getFreeDiskStorageAsync()); } catch { setFree(null); }
  }, []);

  useEffect(() => { void refresh(); const sub = Battery.addBatteryLevelListener((e: Battery.BatteryLevelEvent) => setBattery(e.batteryLevel >= 0 ? Math.round(e.batteryLevel * 100) : null)); return () => sub.remove(); }, [refresh]);

  const tryUnlock = useCallback(async () => {
    setBusy(true);
    try { await authenticateBiometric(); setLocked(false); }
    catch (e) { Alert.alert('Não foi possível desbloquear', e instanceof Error ? e.message : 'Tente novamente.'); }
    finally { setBusy(false); }
  }, []);

  useEffect(() => {
    (async () => {
      const loaded = await loadSettings();
      setSettings(loaded);
      setSettingsLoaded(true);
      if (loaded.biometricLock) { setLocked(true); void tryUnlock(); }
    })();
  }, [tryUnlock]);

  const scanPhotos = async () => {
    setBusy(true);
    try {
      const perm = await MediaLibrary.requestPermissionsAsync(false, ['photo']);
      if (!perm.granted) { Alert.alert('Acesso não concedido', 'Sem acesso à biblioteca, não é possível analisar suas fotos. Nenhum arquivo foi alterado.'); return; }
      const r = await MediaLibrary.getAssetsAsync({ mediaType: 'photo', first: 60 });
      setPhotos(r.totalCount);
      setLibrary(r.assets.map((a: MediaLibrary.Asset) => ({ id: a.id, uri: a.uri, filename: a.filename, creationTime: a.creationTime })));
      setSelected(new Set());
    } catch (e) { Alert.alert('Falha na análise', e instanceof Error ? e.message : 'Tente novamente.'); }
    finally { setBusy(false); }
  };

  const toggleSelect = (id: string) => setSelected((prev: Set<string>) => { const next = new Set(prev); if (next.has(id)) next.delete(id); else next.add(id); return next; });

  const confirmDelete = async () => {
    const ids = Array.from(selected);
    setConfirmVisible(false);
    setBusy(true);
    try {
      const perm = await MediaLibrary.getPermissionsAsync();
      if (!perm.granted) {
        const req = await MediaLibrary.requestPermissionsAsync(false, ['photo']);
        if (!req.granted) { Alert.alert('Permissão necessária', 'Conceda acesso à biblioteca de fotos para excluir os itens selecionados.'); return; }
      }
      const ok = await MediaLibrary.deleteAssetsAsync(ids);
      if (ok) {
        setLibrary((prev: Photo[]) => prev.filter((p: Photo) => !selected.has(p.id)));
        setPhotos((prev: number | null) => (prev !== null ? Math.max(0, prev - ids.length) : prev));
        setSelected(new Set());
        Alert.alert('Concluído', `${ids.length} arquivo(s) excluído(s).`);
      } else {
        Alert.alert('Não foi possível excluir', 'A operação foi cancelada ou recusada pelo sistema.');
      }
    } catch (e) { Alert.alert('Falha ao excluir', e instanceof Error ? e.message : 'Tente novamente.'); }
    finally { setBusy(false); }
  };

  const onToggleCreator = async (value: boolean) => { setSettings((prev: Settings) => ({ ...prev, proUnlocked: value })); await setProUnlocked(value); };
  const onToggleBiometric = async (value: boolean) => {
    if (value) { try { await authenticateBiometric(); } catch (e) { Alert.alert('Não foi possível ativar', e instanceof Error ? e.message : 'Tente novamente.'); return; } }
    setSettings((prev: Settings) => ({ ...prev, biometricLock: value })); await setBiometricLock(value);
  };

  const fmt = (n: number | null) => n === null ? 'Não disponível' : `${(n / 1024 ** 3).toFixed(1)} GB`;

  if (settingsLoaded && settings.biometricLock && locked) {
    return <KeyboardAvoidingView behavior="padding" style={s.loginRoot}><StatusBar style="light" /><View style={s.loginCard}><View style={s.brandMark}><Text style={s.zap}>✦</Text></View><Text style={s.loginBrand}>CleanOS <Text style={{ color: cyan }}>AI</Text></Text><Text style={s.loginOverline}>BLOQUEIO LOCAL</Text><Text style={s.loginTitle}>Desbloqueie para continuar</Text><Text style={s.loginSubtitle}>Use a biometria do seu aparelho. Nenhuma conta ou senha é necessária — o bloqueio fica só neste dispositivo.</Text><TouchableOpacity style={s.loginButton} onPress={tryUnlock} disabled={busy}><Text style={s.loginButtonText}>{busy ? 'Verificando…' : 'Desbloquear'}</Text></TouchableOpacity><Text style={s.loginFoot}>Você pode desativar isso a qualquer momento em Conta.</Text></View></KeyboardAvoidingView>;
  }

  return <View style={s.root}><StatusBar style="light" />
    <View style={s.header}><View style={s.brandMark}><Text style={s.zap}>✦</Text></View><View style={{ flex: 1 }}><Text style={s.brand}>CleanOS <Text style={{ color: cyan }}>AI</Text></Text><Text style={s.kicker}>CUIDADO INTELIGENTE</Text></View><View style={s.online} /></View>

    <ScrollView contentContainerStyle={s.content}>
      {tab === 'Início' && <>
        <View style={s.greeting}><Text style={s.overline}>SEU DISPOSITIVO</Text><Text style={s.title}>Tecnologia que cuida.</Text><Text style={s.subtitle}>Mais espaço para o que importa.</Text></View>
        <View style={s.healthCard}><View style={s.healthTop}><View><Text style={s.overline}>SAÚDE DO SISTEMA</Text><Text style={s.healthTitle}>Tudo sob controle</Text></View><View style={s.healthBadge}><View style={s.online} /><Text style={s.healthBadgeText}>ESTÁVEL</Text></View></View><View style={s.separator} /><View style={s.stats}><View style={s.stat}><Text style={s.statLabel}>Bateria</Text><Text style={s.statValue}>{battery === null ? '—' : `${battery}%`}</Text><View style={s.track}><View style={[s.fill, { width: `${battery ?? 0}%`, backgroundColor: battery !== null && battery < 20 ? '#FF9C65' : cyan }]} /></View></View><View style={s.divider} /><View style={s.stat}><Text style={s.statLabel}>Espaço livre</Text><Text style={s.statValue}>{fmt(free)}</Text><Text style={s.statHint}>armazenamento do dispositivo</Text></View></View></View>
        <View style={s.sectionHeader}><Text style={s.sectionTitle}>Seu cuidado diário</Text><Text style={s.sectionSub}>Ações seguras, sempre com você no controle</Text></View>
        <TouchableOpacity style={s.actionCard} onPress={() => { setTab('Analisar'); void scanPhotos(); }} disabled={busy}><View style={[s.actionIcon, { backgroundColor: '#152D49' }]}><Text style={{ color: '#75BEFF', fontSize: 20 }}>▧</Text></View><View style={s.actionText}><Text style={s.actionTitle}>Analisar biblioteca</Text><Text style={s.actionDesc}>{photos === null ? 'Encontre padrões nas suas fotos' : `${photos} fotos acessíveis nesta sessão`}</Text></View><Text style={s.chevron}>{busy ? '…' : '›'}</Text></TouchableOpacity>
        <TouchableOpacity style={s.actionCard} onPress={() => Alert.alert('Limpeza protegida', 'No iOS, o CleanOS não pode apagar cache de outros apps. Você pode revisar e excluir fotos na aba Analisar.')}><View style={[s.actionIcon, { backgroundColor: '#18342D' }]}><Text style={{ color: '#63DAB4', fontSize: 19 }}>⌁</Text></View><View style={s.actionText}><Text style={s.actionTitle}>Limpeza inteligente</Text><Text style={s.actionDesc}>Ações compatíveis com as regras do sistema</Text></View><Text style={s.chevron}>›</Text></TouchableOpacity>
        <TouchableOpacity style={s.actionCard} onPress={refresh}><View style={[s.actionIcon, { backgroundColor: '#28213C' }]}><Text style={{ color: '#B69AFF', fontSize: 17 }}>◉</Text></View><View style={s.actionText}><Text style={s.actionTitle}>Saúde da bateria</Text><Text style={s.actionDesc}>Leitura local pelo sensor do sistema</Text></View><Text style={s.chevron}>›</Text></TouchableOpacity>
        <View style={s.note}><Text style={s.noteIcon}>◇</Text><Text style={s.noteText}>Sua privacidade é prioridade. Análises acontecem no dispositivo. Nenhum arquivo é excluído sem sua confirmação.</Text></View>
        <View style={s.sectionHeader}><Text style={s.sectionTitle}>CleanOS Pro</Text><Text style={s.sectionSub}>{settings.proUnlocked ? 'Acesso Pro liberado neste dispositivo.' : 'Escolha um plano para ativar quando as lojas forem configuradas.'}</Text></View>
        {settings.proUnlocked
          ? <View style={s.planCard}><View><Text style={s.planName}>Pro ativo</Text><Text style={s.planInfo}>Liberado no Modo Criador, sem cobrança</Text></View><Text style={[s.planChevron, { color: '#63DAB4' }]}>✓</Text></View>
          : <>
            <View style={s.planCard}><View><Text style={s.planName}>Pro Mensal</Text><Text style={s.planInfo}>Sincronização e relatórios semanais</Text></View><Text style={s.planChevron}>›</Text></View>
            <View style={s.planCard}><View><Text style={s.planName}>Pro Anual · Lifetime</Text><Text style={s.planInfo}>Compras precisam de IDs de loja e validação server-side.</Text></View><Text style={s.planChevron}>›</Text></View>
          </>}
      </>}

      {tab === 'Analisar' && <>
        <View style={s.greeting}><Text style={s.overline}>SUA BIBLIOTECA</Text><Text style={s.title}>Revise e escolha.</Text><Text style={s.subtitle}>Nada é excluído sem sua permissão explícita.</Text></View>
        <TouchableOpacity style={s.actionCard} onPress={scanPhotos} disabled={busy}><View style={[s.actionIcon, { backgroundColor: '#152D49' }]}><Text style={{ color: '#75BEFF', fontSize: 18 }}>↻</Text></View><View style={s.actionText}><Text style={s.actionTitle}>{busy ? 'Analisando…' : 'Atualizar análise'}</Text><Text style={s.actionDesc}>{library.length} foto(s) carregada(s) nesta sessão</Text></View></TouchableOpacity>
        {library.length === 0 && <View style={s.note}><Text style={s.noteIcon}>◇</Text><Text style={s.noteText}>Toque em "Atualizar análise" e conceda acesso à biblioteca para ver suas fotos aqui.</Text></View>}
        {library.map((p: Photo) => <TouchableOpacity key={p.id} style={s.photoRow} onPress={() => toggleSelect(p.id)}>
          <Image source={{ uri: p.uri }} style={s.photoThumb} />
          <View style={s.actionText}><Text style={s.actionTitle} numberOfLines={1}>{p.filename}</Text><Text style={s.actionDesc}>Toque para {selected.has(p.id) ? 'desmarcar' : 'selecionar'}</Text></View>
          <View style={[s.checkbox, selected.has(p.id) && s.checkboxChecked]}>{selected.has(p.id) && <Text style={s.checkboxMark}>✓</Text>}</View>
        </TouchableOpacity>)}
      </>}

      {tab === 'Relatórios' && <>
        <View style={s.greeting}><Text style={s.overline}>RESUMO LOCAL</Text><Text style={s.title}>Seus relatórios.</Text><Text style={s.subtitle}>Gerados no dispositivo, sem precisar de conta.</Text></View>
        <View style={s.healthCard}><Text style={s.healthTitle}>Última análise</Text><Text style={s.noteText}>{photos === null ? 'Nenhuma análise realizada ainda nesta sessão.' : `${photos} fotos encontradas · ${library.length} carregadas para revisão`}</Text></View>
        {!settings.proUnlocked && <View style={s.note}><Text style={s.noteIcon}>◇</Text><Text style={s.noteText}>Histórico completo e relatórios semanais fazem parte do CleanOS Pro.</Text></View>}
      </>}

      {tab === 'Conta' && <>
        <View style={s.greeting}><Text style={s.overline}>PREFERÊNCIAS</Text><Text style={s.title}>Sua conta.</Text><Text style={s.subtitle}>Tudo local neste aparelho — sem login.</Text></View>
        <View style={s.sectionHeader}><Text style={s.sectionTitle}>Plano</Text></View>
        <View style={s.settingRow}><View style={{ flex: 1 }}><Text style={s.settingTitle}>Modo Criador</Text><Text style={s.settingDesc}>Libera o acesso Pro neste aparelho, sem assinatura</Text></View><Switch value={settings.proUnlocked} onValueChange={onToggleCreator} trackColor={{ false: '#243449', true: cyan }} /></View>
        <View style={s.sectionHeader}><Text style={s.sectionTitle}>Segurança</Text></View>
        <View style={s.settingRow}><View style={{ flex: 1 }}><Text style={s.settingTitle}>Bloqueio biométrico</Text><Text style={s.settingDesc}>Exigir Face ID/Touch ID/biometria ao abrir o app</Text></View><Switch value={settings.biometricLock} onValueChange={onToggleBiometric} trackColor={{ false: '#243449', true: cyan }} /></View>
        <View style={s.sectionHeader}><Text style={s.sectionTitle}>Sobre</Text></View>
        <View style={s.healthCard}><Text style={s.noteText}>CleanOS AI · v0.1.0 · {Platform.OS === 'ios' ? 'iOS' : 'Android'}</Text><Text style={[s.noteText, { marginTop: 6 }]}>Seus arquivos e fotos nunca saem do dispositivo. Exclusões sempre pedem sua confirmação antes de acontecer.</Text></View>
      </>}
    </ScrollView>

    {tab === 'Analisar' && selected.size > 0 && <View style={s.deleteBar}><Text style={s.deleteBarText}>{selected.size} selecionada(s)</Text><TouchableOpacity style={s.deleteButton} onPress={() => setConfirmVisible(true)} disabled={busy}><Text style={s.deleteButtonText}>Excluir</Text></TouchableOpacity></View>}

    <View style={s.tabbar}>{(['Início', 'Analisar', 'Relatórios', 'Conta'] as Tab[]).map((x, i) => <TouchableOpacity key={x} onPress={() => { setTab(x); if (x === 'Analisar' && library.length === 0) void scanPhotos(); }} style={s.tab}><Text style={[s.tabIcon, tab === x && s.tabActive]}>{['⌂', '⌕', '▤', '◉'][i]}</Text><Text style={[s.tabLabel, tab === x && s.tabActive]}>{x}</Text></TouchableOpacity>)}</View>

    <Modal visible={confirmVisible} transparent animationType="fade" onRequestClose={() => setConfirmVisible(false)}>
      <View style={s.modalBackdrop}><View style={s.modalCard}>
        <Text style={s.modalTitle}>Permitir exclusão?</Text>
        <Text style={s.modalBody}>{`O CleanOS vai excluir ${selected.size} arquivo(s) da sua biblioteca. Essa ação não pode ser desfeita.`}</Text>
        <View style={s.modalActions}>
          <TouchableOpacity style={s.modalCancel} onPress={() => setConfirmVisible(false)}><Text style={s.modalCancelText}>Cancelar</Text></TouchableOpacity>
          <TouchableOpacity style={s.modalDanger} onPress={confirmDelete}><Text style={s.modalDangerText}>Excluir</Text></TouchableOpacity>
        </View>
      </View></View>
    </Modal>
  </View>;
}

const s: any = StyleSheet.create({ root: { flex: 1, backgroundColor: '#080D16' }, header: { height: 76, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 22, borderBottomWidth: 1, borderColor: '#172337', gap: 11 }, brandMark: { width: 34, height: 34, backgroundColor: '#102D42', borderRadius: 11, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#246077' }, zap: { fontSize: 20, color: cyan }, brand: { fontSize: 17, fontWeight: '800', color: '#EDF5FF', letterSpacing: -.4 }, kicker: { fontSize: 8, color: '#71839C', letterSpacing: 1.3, marginTop: 3 }, online: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#4CDEAE', shadowColor: '#4CDEAE', shadowOpacity: .8, shadowRadius: 6 }, content: { paddingHorizontal: 20, paddingTop: 24, paddingBottom: 26 }, greeting: { marginBottom: 20 }, overline: { fontSize: 9, color: '#8094AC', letterSpacing: 1.35, fontWeight: '700' }, title: { fontSize: 26, color: '#F2F7FD', fontWeight: '800', letterSpacing: -.8, marginTop: 7 }, subtitle: { fontSize: 12, color: muted, marginTop: 5 }, healthCard: { padding: 17, borderWidth: 1, borderColor: '#1B3450', backgroundColor: '#0D1B2B', borderRadius: 13 }, healthTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, healthTitle: { fontSize: 16, fontWeight: '700', color: '#EEF6FF', marginTop: 7 }, healthBadge: { flexDirection: 'row', gap: 7, alignItems: 'center', borderWidth: 1, borderColor: '#205145', paddingVertical: 6, paddingHorizontal: 9, borderRadius: 20 }, healthBadgeText: { fontSize: 8, color: '#67DAB6', fontWeight: '700', letterSpacing: .7 }, separator: { height: 1, backgroundColor: '#1A2D42', marginVertical: 15 }, stats: { flexDirection: 'row', alignItems: 'center' }, stat: { flex: 1 }, statLabel: { fontSize: 10, color: '#899AB0' }, statValue: { fontSize: 18, color: '#EAF5FF', fontWeight: '700', marginTop: 6 }, track: { height: 4, backgroundColor: '#1A2A3C', borderRadius: 5, marginTop: 9, width: '82%' }, fill: { height: 4, borderRadius: 5 }, statHint: { fontSize: 8, color: '#77899F', marginTop: 7 }, divider: { width: 1, height: 46, backgroundColor: '#24364A', marginHorizontal: 15 }, sectionHeader: { marginTop: 25, marginBottom: 11 }, sectionTitle: { fontSize: 15, color: '#EDF4FC', fontWeight: '700' }, sectionSub: { fontSize: 10, color: '#798AA0', marginTop: 4 }, actionCard: { minHeight: 69, flexDirection: 'row', alignItems: 'center', padding: 12, backgroundColor: '#0D1521', borderWidth: 1, borderColor: '#1B283B', borderRadius: 10, marginBottom: 8 }, actionIcon: { height: 39, width: 39, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginRight: 12 }, actionText: { flex: 1 }, actionTitle: { fontSize: 12, fontWeight: '700', color: '#E8F1FC' }, actionDesc: { fontSize: 9, color: '#8191A7', marginTop: 4 }, chevron: { fontSize: 22, color: '#71849B', paddingHorizontal: 7 }, note: { flexDirection: 'row', gap: 9, padding: 12, backgroundColor: '#101C29', borderRadius: 9, marginTop: 8 }, noteIcon: { color: cyan, fontSize: 16 }, noteText: { color: '#94A4B8', fontSize: 9, lineHeight: 14, flex: 1 }, planCard: { padding: 13, backgroundColor: '#0D1521', borderWidth: 1, borderColor: '#1B283B', borderRadius: 9, marginBottom: 8, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, planName: { fontSize: 11, color: '#E7EFFA', fontWeight: '700' }, planInfo: { fontSize: 9, color: '#8191A7', marginTop: 5 }, planChevron: { fontSize: 22, color: cyan }, tabbar: { height: 64, borderTopWidth: 1, borderColor: '#182537', backgroundColor: '#0A111D', flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' }, tab: { alignItems: 'center', gap: 3, minWidth: 55 }, tabIcon: { fontSize: 17, color: '#718198' }, tabLabel: { fontSize: 8, color: '#718198' }, tabActive: { color: cyan }, photoRow: { flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: '#0D1521', borderWidth: 1, borderColor: '#1B283B', borderRadius: 10, marginBottom: 8, gap: 11 }, photoThumb: { width: 44, height: 44, borderRadius: 8, backgroundColor: '#1A2A3C' }, checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 1.5, borderColor: '#3A5069', alignItems: 'center', justifyContent: 'center' }, checkboxChecked: { backgroundColor: cyan, borderColor: cyan }, checkboxMark: { color: '#07131E', fontSize: 13, fontWeight: '800' }, deleteBar: { position: 'absolute', bottom: 70, left: 16, right: 16, backgroundColor: '#0D1521', borderWidth: 1, borderColor: '#2A4257', borderRadius: 12, padding: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, deleteBarText: { color: '#E8F1FC', fontSize: 11, fontWeight: '700' }, deleteButton: { backgroundColor: '#E5484D', paddingVertical: 9, paddingHorizontal: 18, borderRadius: 8 }, deleteButtonText: { color: '#FFF', fontSize: 11, fontWeight: '800' }, settingRow: { flexDirection: 'row', alignItems: 'center', padding: 13, backgroundColor: '#0D1521', borderWidth: 1, borderColor: '#1B283B', borderRadius: 10, marginBottom: 8, gap: 10 }, settingTitle: { fontSize: 12, fontWeight: '700', color: '#E8F1FC' }, settingDesc: { fontSize: 9, color: '#8191A7', marginTop: 4 }, modalBackdrop: { flex: 1, backgroundColor: 'rgba(3,7,13,0.72)', alignItems: 'center', justifyContent: 'center', padding: 28 }, modalCard: { width: '100%', backgroundColor: '#0D1521', borderWidth: 1, borderColor: '#2A4257', borderRadius: 14, padding: 20 }, modalTitle: { fontSize: 16, fontWeight: '800', color: '#F2F7FD' }, modalBody: { fontSize: 11, color: muted, lineHeight: 16, marginTop: 9 }, modalActions: { flexDirection: 'row', gap: 10, marginTop: 18 }, modalCancel: { flex: 1, height: 44, borderRadius: 8, borderWidth: 1, borderColor: '#2A4257', alignItems: 'center', justifyContent: 'center' }, modalCancelText: { color: '#C7D3E2', fontSize: 12, fontWeight: '700' }, modalDanger: { flex: 1, height: 44, borderRadius: 8, backgroundColor: '#E5484D', alignItems: 'center', justifyContent: 'center' }, modalDangerText: { color: '#FFF', fontSize: 12, fontWeight: '800' } });
Object.assign(s, StyleSheet.create({ loginRoot: { flex: 1, backgroundColor: '#080D16', justifyContent: 'center', padding: 24 }, loginCard: { padding: 22, backgroundColor: '#0D1521', borderWidth: 1, borderColor: '#1B3450', borderRadius: 16 }, loginBrand: { fontSize: 23, fontWeight: '800', color: '#EDF5FF', marginTop: 15 }, loginOverline: { fontSize: 9, color: cyan, letterSpacing: 1.5, fontWeight: '700', marginTop: 28 }, loginTitle: { fontSize: 21, color: '#F2F7FD', fontWeight: '800', marginTop: 8 }, loginSubtitle: { fontSize: 11, color: muted, lineHeight: 17, marginTop: 6, marginBottom: 18 }, loginButton: { height: 48, backgroundColor: '#43CBEA', borderRadius: 8, alignItems: 'center', justifyContent: 'center', marginTop: 8 }, loginButtonText: { color: '#07131E', fontSize: 12, fontWeight: '800' }, loginFoot: { fontSize: 9, color: '#7E91A8', lineHeight: 14, marginTop: 14 } }));
export default App;
