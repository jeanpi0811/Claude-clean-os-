import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY_PRO = 'cleanos.settings.pro.v1';
const KEY_BIOMETRIC = 'cleanos.settings.biometric.v1';

export interface Settings {
  proUnlocked: boolean;
  biometricLock: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  proUnlocked: false,
  biometricLock: false,
};

/**
 * Todas as preferências abaixo são locais ao dispositivo (AsyncStorage).
 * Não existe login, conta ou backend envolvido: são apenas ajustes do
 * usuário/criador para este aparelho.
 */
export async function loadSettings(): Promise<Settings> {
  try {
    const [pro, biometric] = await Promise.all([
      AsyncStorage.getItem(KEY_PRO),
      AsyncStorage.getItem(KEY_BIOMETRIC),
    ]);
    return {
      proUnlocked: pro === '1',
      biometricLock: biometric === '1',
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export async function setProUnlocked(value: boolean): Promise<void> {
  await AsyncStorage.setItem(KEY_PRO, value ? '1' : '0');
}

export async function setBiometricLock(value: boolean): Promise<void> {
  await AsyncStorage.setItem(KEY_BIOMETRIC, value ? '1' : '0');
}
