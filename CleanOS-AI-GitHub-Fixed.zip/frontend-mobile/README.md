# Mobile React Native

Aplicativo Expo SDK 55 / React Native 0.83 com tela de saúde, nível da bateria, armazenamento livre e acesso consentido à biblioteca. Android mínimo API 24 (Android 7), compilação e target API 36. iOS mínimo 15.1. No iOS, o ecrã inicial solicita login Master com e-mail e senha pela API, provisionado pelo seed administrativo; o token é protegido no Keychain via SecureStore. Android não recebe esse gate de login Master.

No iOS, APIs sandbox impedem limpeza de cache de outros apps e enumeração geral de apps/uso. O app solicita permissão de foto granular e deve respeitar seleção limitada. A exclusão de mídias por `expo-media-library` e compras IAP ainda não estão ativadas; não se apresenta compra como funcional sem produto/validação configurados. A compra nativa precisa de Expo dev client + StoreKit 2/Play Billing e verificação backend.

Os projetos nativos gerados estão em `android/` e `ios/`. Regenerar: `npm run prebuild -w @cleanos/mobile`. Comandos: `npm run start -w @cleanos/mobile`; em macOS, `npm run ios -w @cleanos/mobile`; Android: `npm run android -w @cleanos/mobile`; verificação `npm run typecheck -w @cleanos/mobile`. Xcode 16.1+ é necessário para build/assinatura iOS; use um Mac com Xcode, Pods instalados e Apple Team configurado. Defina bundle IDs e conta de publicação definitivos antes da loja.
