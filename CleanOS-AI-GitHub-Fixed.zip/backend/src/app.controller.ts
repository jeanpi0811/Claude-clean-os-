import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { AppService } from './app.service';
import { CleanupDto, CredentialsDto, DeviceDto, JwtGuard, RefreshDto, SyncDto } from './auth';
import { PrismaService } from './prisma.service';
import Redis from 'ioredis';
@Controller()
export class AppController {
 constructor(private service:AppService,private db:PrismaService,private redis:Redis){}
 @Get('health') async health(){
   const checks={database:'ok',redis:'ok'};
   try{await this.db.$queryRaw`SELECT 1`;}catch{checks.database='unavailable';}
   try{await this.redis.ping();}catch{checks.redis='unavailable';}
   return {status:Object.values(checks).every(x=>x==='ok')?'ok':'degraded',checks, timestamp:new Date().toISOString()};
 }
 @Post('auth/register') register(@Body() dto:CredentialsDto){return this.service.register(dto.email,dto.password);}
 @Post('auth/login') login(@Body() dto:CredentialsDto){return this.service.login(dto.email,dto.password);}
 @Post('auth/refresh') refresh(@Body() dto:RefreshDto){return this.service.refresh(dto.refreshToken);}
 @UseGuards(JwtGuard) @Post('auth/logout') logout(@Req() r:Request & {user:{id:string}}){return this.service.logout(r.user.id);}
 @UseGuards(JwtGuard) @Get('devices') devices(@Req() r:Request & {user:{id:string}}){return this.service.listDevices(r.user.id);}
 @UseGuards(JwtGuard) @Post('devices') upsertDevice(@Req() r:Request & {user:{id:string}},@Body() dto:DeviceDto){return this.service.upsertDevice(r.user.id,dto);}
 @UseGuards(JwtGuard) @Post('sync/events') sync(@Req() r:Request & {user:{id:string}},@Body() dto:SyncDto){return this.service.addSyncEvent(r.user.id,dto);}
 @UseGuards(JwtGuard) @Get('sync/events') events(@Req() r:Request & {user:{id:string}},@Req() _r:Request){return this.service.getSyncEvents(r.user.id,_r.query.after as string|undefined);}
 @UseGuards(JwtGuard) @Post('cleanups') addCleanup(@Req() r:Request & {user:{id:string}},@Body() dto:CleanupDto){return this.service.addCleanup(r.user.id,dto);}
 @UseGuards(JwtGuard) @Get('cleanups') cleanups(@Req() r:Request & {user:{id:string}}){return this.service.listCleanups(r.user.id);}
 @UseGuards(JwtGuard) @Get('reports') reports(@Req() r:Request & {user:{id:string}}){return this.service.listReports(r.user.id);}
}
